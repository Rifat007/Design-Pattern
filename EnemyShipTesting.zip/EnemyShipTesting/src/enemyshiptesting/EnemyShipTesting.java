
package enemyshiptesting;

import java.util.*;

public class EnemyShipTesting {

   
    public static void main(String[] args) {
        
        EnemyShipFactory shipFactory=new EnemyShipFactory();
        //EnemyShip theEnemy=null;
        Random randomGenerator = new Random();
        
        Scanner userInput=new Scanner(System.in);
        int i,j,n;
        n=userInput.nextInt();
        for(i=1;i<=n;i++)
        {
            int randomInt = randomGenerator.nextInt(100);
            if(randomInt%3==0)
            {
                doStuffEnemy(shipFactory.makeEnemyShip("U"));
            }
            else if(randomInt%3==1)
            {
                doStuffEnemy(shipFactory.makeEnemyShip("R"));
            }
            else if(randomInt%3==2)
            {
                doStuffEnemy(shipFactory.makeEnemyShip("B"));
            }
        }
//        System.out.println("What type Ship??(U/R/B)");
//        
//        if(userInput.hasNextLine())
//        {
//            String typeOfShip=userInput.nextLine();
//            theEnemy=shipFactory.makeEnemyShip(typeOfShip);
//        }
        
//        if(theEnemy!=null)
//        {
//            doStuffEnemy(theEnemy);
//        }
        // TODO code application logic here
    }
    
    public static void doStuffEnemy(EnemyShip anEnemyShip)
    {
        anEnemyShip.displayEnemyShip();
        anEnemyShip.followHeroShip();
        anEnemyShip.enemyShipShoots();
        System.out.println("");
    }
    
}
